package com.sub.chat.chat_app_backend.controllers;

import java.time.LocalDateTime;

import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import com.sub.chat.chat_app_backend.entities.Message;
import com.sub.chat.chat_app_backend.entities.Room;
import com.sub.chat.chat_app_backend.payload.MessageRequest;
import com.sub.chat.chat_app_backend.repositories.RoomRepository;


@Controller

@CrossOrigin(origins="http://localhost:3000")
public class ChatControllers {

    public RoomRepository roomRepository;

    public ChatControllers(RoomRepository roomRepository)
    {
        this.roomRepository=roomRepository;
    }
    
    @MessageMapping("/sendMessage/{roomId}")
    @SendTo("/topic/room/{roomId}")
    public Message sendMessage(@DestinationVariable String roomId, MessageRequest request)
     {
        Room room = roomRepository.findByRoomId(request.getRoomId());

     if (room == null) {
        throw new RuntimeException("Room not found!");
        }

     if (request.getContent() == null || request.getSender() == null) {
        throw new RuntimeException("Invalid message data!");
        }

    Message message = new Message();
    message.setContent(request.getContent());
    message.setSender(request.getSender());
    message.setTimeStamp(LocalDateTime.now());

    room.getMessages().add(message);
    roomRepository.save(room);

    return message;
    }

}
