package com.sub.chat.chat_app_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatAppBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
