package com.blgmanagement.blgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlgmtApplication.class, args);
	}

}
