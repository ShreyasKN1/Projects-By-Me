import Die from "./Die";
import { useState ,useEffect,useRef} from "react";
import {nanoid} from "nanoid";
import Confetti from "react-confetti";



function App() {

  const [Dice,setDice]=useState(()=>generateRandom())
  const buttonRef=useRef(null);

  const gameWon=Dice.every(die=> die.isheld) && Dice.every(die=>die.value==Dice[0].value)


  useEffect(()=>{
    if(gameWon)
    {
      buttonRef.current.focus();
    }
  },[gameWon])

 
  function generateRandom(){
    return new Array(10)
            .fill(0)
            .map(() =>
              ({
                value: Math.ceil(Math.random() * 6),
                isheld:false,
                id:nanoid()
              }))
    }


    function hold(id)
    {
      setDice(olddie=> olddie.map(die=>
        id===die.id?{...die,isheld:!die.isheld}:die
      ))
    }


    function RollDice()
    {
      if(!gameWon)
      {
       setDice(olddie=>olddie.map(die=>
        die.isheld?die:{...die,value:Math.ceil(Math.random() *6)}
       ))
      }
      else{
        setDice(generateRandom())
      }
    }

const diceElement=Dice.map(dieObj=> <Die key={dieObj.id} id={dieObj.id} isheld={dieObj.isheld} value={dieObj.value} hold={()=>hold(dieObj.id)}/>)


  return (
   <main>
     {gameWon && <Confetti/>}
    <h1 className="title">Tenzies</h1>
    <p className="instructions">Roll until all dice are the same. Click each die to freeze it at its current value between rolls.</p>
    <div className="die-container">
      {diceElement}
    </div>
    <button ref={buttonRef} className="roll-dice"onClick={RollDice}>{gameWon?"New Game":"ReRoll"}</button>
   </main>
   
  );
}

export default App;
