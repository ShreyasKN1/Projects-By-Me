package com.sub.chat.chat_app_backend.controllers;

import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RequestParam; for pagination
import org.springframework.web.bind.annotation.RestController;

import com.sub.chat.chat_app_backend.entities.Message;
import com.sub.chat.chat_app_backend.entities.Room;
import com.sub.chat.chat_app_backend.repositories.RoomRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
// import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api/rooms")

public class RoomControllers {


    @Autowired
    private RoomRepository roomRepository;




    @PostMapping
    public ResponseEntity<?> createRoom(@RequestBody Room room) {
        if (room == null || room.getRoomId() == null || room.getRoomId().trim().isEmpty()) {
            return ResponseEntity.badRequest().body("Room ID is required.");
        }
    
        if (roomRepository.findByRoomId(room.getRoomId()) != null) {
            return ResponseEntity.badRequest().body("Room already exists.");
        }
    
        roomRepository.save(room);
        return ResponseEntity.status(HttpStatus.CREATED).body(room);
    }
    
    

     @GetMapping("/{roomId}")
    public ResponseEntity<?> joinRoom(@PathVariable String roomId)
     {
        Room room = roomRepository.findByRoomId(roomId);
            if (room == null)
            {
                Room newRoom = new Room();
                newRoom.setRoomId(roomId);
                roomRepository.save(newRoom);
                return ResponseEntity.status(HttpStatus.CREATED).body(newRoom);
            }
        return ResponseEntity.status(HttpStatus.OK).body(room);
    }
    

     @GetMapping("/{roomId}/messages")
    public ResponseEntity<List<Message>> getMessages(
            @PathVariable String roomId
    ) {
        Room room = roomRepository.findByRoomId(roomId);
        if (room == null) {
            return ResponseEntity.badRequest().build();
        }
        List<Message> messages = room.getMessages();
        return ResponseEntity.status(HttpStatus.OK).body(messages);

    }
}
