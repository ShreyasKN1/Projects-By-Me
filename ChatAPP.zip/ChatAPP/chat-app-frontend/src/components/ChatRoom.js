import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Client } from "@stomp/stompjs";
import SockJS from "sockjs-client";
import axios from "axios";

const ChatRoom = () => {
  const { roomId } = useParams();
  const [messages, setMessages] = useState([]);
  const [message, setMessage] = useState("");
  const [stompClient, setStompClient] = useState(null);

  useEffect(() => {
    const client = new Client({
      webSocketFactory: () => new SockJS("http://localhost:8080/chat"),
      reconnectDelay: 5000,
    });

    client.onConnect = () => {
      console.log("Connected to WebSocket");
      client.subscribe(`/topic/room/${roomId}`, (msg) => {
        setMessages((prev) => [...prev, JSON.parse(msg.body)]);
      });
    };

    client.activate();
    setStompClient(client);

    axios.get(`http://localhost:8080/api/rooms/${roomId}/messages`)
      .then((res) => setMessages(res.data))
      .catch(() => console.log("Error fetching messages"));

    return () => client.deactivate();
  }, [roomId]);

  const sendMessage = () => {
    if (stompClient && message.trim()) {
      const msg = { sender: "User", content: message };
      stompClient.publish({
        destination: `/app/sendMessage/${roomId}`,
        body: JSON.stringify({ roomId, ...msg }),
      });
      setMessage("");
    }
  };

  return (
    <div className="chat-container">
      <h2>Chat Room: {roomId}</h2>
      <div className="messages">
        {messages.map((msg, index) => (
          <div key={index} className="message">
            <strong>{msg.sender}: </strong> {msg.content}
          </div>
        ))}
      </div>
      <div className="input-area">
        <input
          type="text"
          placeholder="Type a message..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
        <button onClick={sendMessage}>Send</button>
      </div>
    </div>
  );
};

export default ChatRoom;
