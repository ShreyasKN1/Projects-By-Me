import React from 'react';
import UserList from './components/UserList';

function App()
{
    return(
        <div classname="App">
            <h1>OnlyBlogs</h1>
            <UserList/>
        </div>

    );
}

export default App;