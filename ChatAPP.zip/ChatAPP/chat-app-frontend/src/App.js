import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import RoomSelection from "./components/RoomSelection";
import ChatRoom from "./components/ChatRoom";
import "./App.css";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<RoomSelection />} />
        <Route path="/chat/:roomId" element={<ChatRoom />} />
      </Routes>
    </Router>
  );
}

export default App;
