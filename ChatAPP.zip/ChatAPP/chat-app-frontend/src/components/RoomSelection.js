import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const RoomSelection = () => {
  const [roomId, setRoomId] = useState("");
  const navigate = useNavigate();

  const handleJoinRoom = async () => {
    if (!roomId.trim()) return alert("Enter a room ID!");
    try {
      await axios.post("http://localhost:8080/api/rooms", {roomId}, {
        headers: { "Content-Type": "application/json" },
      });
    } catch (error) {
      console.log("Room might already exist, proceeding...");
    }
    navigate(`/chat/${roomId}`);
  };

  return (
    <div className="container">
      <h2>Join or Create a Chat Room</h2>
      <input
        type="text"
        placeholder="Enter Room ID"
        value={roomId}
        onChange={(e) => setRoomId(e.target.value)}
      />
      <button onClick={handleJoinRoom}>Join Room</button>
    </div>
  );
};

export default RoomSelection;
